package com.swapnil.microservicedemo.limitsservice;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("limits-service")
public class ConfigurationPro {

   private int maximum ;
   private int miminum;

    public int getMaximum() {
        return maximum;
    }

    public void setMaximum(int maximum) {
        this.maximum = maximum;
    }

    public int getMiminum() {
        return miminum;
    }

    public void setMiminum(int miminum) {
        this.miminum = miminum;
    }
}
