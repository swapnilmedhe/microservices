package com.swapnil.microservicedemo.limitsservice.controller;

import com.swapnil.microservicedemo.limitsservice.ConfigurationPro;
import com.swapnil.microservicedemo.limitsservice.bean.LimitConfigutarion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LimitsConfigController {
    @Autowired
    private ConfigurationPro configuration;
    @GetMapping("/limits")
    public LimitConfigutarion retriveLimitConfig(){
         return new LimitConfigutarion(configuration.getMaximum(),configuration.getMiminum());
    }

}
