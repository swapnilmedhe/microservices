package com.swapnil.microservicedemo.limitsservice.bean;

public class LimitConfigutarion {
  private  int maximum;
  private  int minimum;


    public LimitConfigutarion() {
    }

    public LimitConfigutarion(int maximum, int minimum) {
        this.maximum = maximum;
        this.minimum = minimum;
    }

    public int getMaximum() {
        return maximum;
    }

    public void setMaximum(int maximum) {
        this.maximum = maximum;
    }

    public int getMinimum() {
        return minimum;
    }

    public void setMinimum(int minimum) {
        this.minimum = minimum;
    }
}
